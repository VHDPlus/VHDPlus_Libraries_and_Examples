#include "alt_types.h"
#include "altera_avalon_i2c.h"
#include <unistd.h>

class SCD40
{
private:
    alt_u16 data_ready=0;
    alt_u16 asc_state=2;
    alt_u16 activate=1;
    alt_u16 measurement_interval = 2; //allowed range: 2s - 1800s
    alt_u16 ambient_pressure_mbar = 0; // allowed range: 0 & 700mbar - 1400mbar
    float co2, temp, hum;
    alt_16 status;
    ALT_AVALON_I2C_DEV_t *i2c_dev = NULL;
    
public:
    void i2c_init(void);

    alt_u8 gencrc8(alt_u8 *data);

    alt_8 i2c_write(alt_u8 target_addr, alt_u16 command, const alt_u16* argument, alt_u8 argument_word_size);

    alt_8 i2c_read(alt_u8 target_addr, alt_u16 command, alt_u16* data, alt_u8 data_word_size);

    alt_8 busy();
    
    void begin();
    
    void end();
    
    void read();
    
    float co2_value();
    
    float temp_value();
    
    float hum_value();

};
